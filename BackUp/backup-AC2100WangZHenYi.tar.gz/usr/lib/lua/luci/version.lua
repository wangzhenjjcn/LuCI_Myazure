local pcall, dofile, _G = pcall, dofile, _G

module "luci.version"

distname    = "OpenWrt"
distversion = "WangZhenYi"
 

luciname    = "MyazureServer"
luciversion = "Hong Kong"
